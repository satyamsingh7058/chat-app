# Flutter Chat App UI 

Flutter tutorial on converting a minimal chat app UI desing into fully functional layout with custom widgets.


# Screenshots

![chat app ui](https://i.ibb.co/BsdN7k6/Chat-App.png)
![chat app ui](https://i.ibb.co/B43S32W/Messages.png)
![chat app ui](https://i.ibb.co/wMzC7Vx/Message-Details.png)

# Youtube Tutorial

[![Flutter chat UI Development](http://img.youtube.com/vi/Oj11JaFUeUM/0.jpg)](http://www.youtube.com/watch?v=Oj11JaFUeUM "Flutter Chat UI Development")

